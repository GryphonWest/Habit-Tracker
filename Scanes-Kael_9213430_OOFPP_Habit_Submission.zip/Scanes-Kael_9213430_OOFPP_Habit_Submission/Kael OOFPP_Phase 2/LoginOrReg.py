from tkinter import *
import mysql.connector
import customtkinter
import math
from datetime import datetime 
import HabitTracker as HT
import copy
import mysql



#Handles login and registration
class LoginOrReg:

    customtkinter.set_appearance_mode('dark')
    customtkinter.set_default_color_theme('blue')
    

    def __init__(self, login_username, data, user_id, db = ' '):
        self.db = mysql.connector.connect(host = 'yourneighbourhoodscientist.co.za', user = 'hoodscientist_hoodscientist', password= 'Kscanes3394#', database="hoodscientist_HabitTracker")
        self.cursor = self.db.cursor(dictionary=True)
        self.login_username = login_username
        self.data = data
        self.user_id = user_id

    def shallow_copy(self):
        return copy.copy(self)

    # Asks user if they want to login or register
    def login_or_reg(self, root):
        self.root = customtkinter.CTk()
        self.root.geometry('175x175')
        self.login_button = customtkinter.CTkButton(self.root, text='Login', command=self.login).pack(pady=20)
        self.reg_button = customtkinter.CTkButton(self.root, text='Register', command=self.reg_user).pack(pady=10)
        self.root.mainloop()

    #provides a registration screen for the user to input a password and username
    def reg_user(self):
        self.root.destroy()
        self.reg_window = customtkinter.CTk()
        self.reg_window.geometry('300x300')
        self.reg_username_entry = customtkinter.CTkEntry(self.reg_window, placeholder_text ='Enter a Username')
        self.reg_username_entry.pack(pady=20)
        self.reg_password_entry = customtkinter.CTkEntry(self.reg_window, placeholder_text ='Enter a Password')
        self.reg_password_entry.pack(pady=10)
        self.reg_button = customtkinter.CTkButton(self.reg_window, text = 'Register New User', command = self.commit_user)
        self.reg_button.pack(pady=20)
        self.login_button = customtkinter.CTkButton(self.reg_window, text='Login', command=self.login)
        self.login_button.pack(pady=5)
        self.reg_window.mainloop()

    #Commits the newly registered user to the database
    def commit_user(self):
        self.cursor.execute('SELECT username AND password, COUNT(*) FROM users WHERE username=%s AND password=%s GROUP BY username',(self.reg_username_entry.get(), self.reg_password_entry.get()))
        self.cursor.fetchall()
        self.row_count = self.cursor.rowcount
        if self.row_count == 1:
            self.my_label = customtkinter.CTkLabel(self.reg_window, text = 'User already exists', font=('Arial', 10)).pack(pady=10)
        else:
            self.cursor.execute('INSERT INTO users (username, password) VALUES(%s, %s)', (self.reg_username_entry.get(), self.reg_password_entry.get()))
            self.db.commit()
            self.login()
            self.reg_window.destroy()

    #provides the login screen where the user is asked for an existing username and password
    def login(self):
        self.login_window = customtkinter.CTk()
        self.login_window.geometry('400x400')
        self.login_username_entry = customtkinter.CTkEntry(self.login_window, placeholder_text ='Enter Your Username')
        self.login_username_entry.pack(pady=30)
        self.login_password_entry = customtkinter.CTkEntry(self.login_window, placeholder_text ='Enter Your Password')
        self.login_password_entry.pack(pady=30)
        self.login_username = self.login_username_entry.get()
        self.login_password = self.login_password_entry.get()
        self.log_user_in_button = customtkinter.CTkButton(self.login_window, text = 'Login', command = self.log_user_in).pack(pady=30)
        self.reg_button = customtkinter.CTkButton(self.login_window, text = 'Register New User', command = self.reg_user).pack(pady=20)
        self.login_window.mainloop()

    #Logs the user in
    def log_user_in(self):
        self.habit = HT.HabitTracker(main_window=' ', sorting_options= ' ', sort= ' ', date= ' ')
        self.cursor.execute('SELECT username AND password, COUNT(*) FROM users WHERE username=%s AND password=%s GROUP BY username',(self.login_username_entry.get(), self.login_password_entry.get()))
        self.cursor.fetchall()
        self.row_count = self.cursor.rowcount
        if self.row_count == 1:
            self.cursor.execute('SELECT userID FROM users WHERE username=%s AND password=%s',(self.login_username_entry.get(), self.login_password_entry.get()))
            self.data = self.cursor.fetchone()
            self.user_id = self.data['userID']
            self.habit.main_menu(self.shallow_copy(), tracker= ' ')
            self.login_window.destroy()
        else:
            self.my_label = customtkinter.CTkLabel(self.login_window, text = "User Not Found. Please Try Again.", font=('Helvetica', 10)).pack(pady=10)

    def get_login_username(self):
        return self.login_username


if __name__ == '__main__':
    login_reg = LoginOrReg(login_username=" ", data = ' ', user_id=' '  )
    login_reg.login_or_reg(root=" ")

