from tkinter import *
import mysql.connector
import customtkinter
import math
from datetime import datetime 


#Handles login and registration
class LoginOrReg:

    customtkinter.set_appearance_mode('dark')
    customtkinter.set_default_color_theme('blue')
    

    def __init__(self, db, cursor, login_username, data):
        self.db = mysql.connector.connect(host = 'yourneighbourhoodscientist.co.za', user = 'hoodscientist_hoodscientist', password= 'Kscanes3394#', database="hoodscientist_HabitTracker")
        self.cursor = self.db.cursor()
        self.login_username = login_username
        self.data = data

    # Asks user if they want to login or register
    def login_or_reg(self, root):
        self.root = customtkinter.CTk()
        self.root.geometry('175x175')
        self.login_button = customtkinter.CTkButton(self.root, text='Login', command=self.login).pack(pady=20)
        self.reg_button = customtkinter.CTkButton(self.root, text='Register', command=self.reg_user).pack(pady=10)
        self.root.mainloop()

    #provides a registration screen for the user to input a password and username
    def reg_user(self):
        self.root.destroy()
        self.reg_window = customtkinter.CTk()
        self.reg_window.geometry('300x300')
        self.reg_username_entry = customtkinter.CTkEntry(self.reg_window, placeholder_text ='Enter a Username')
        self.reg_username_entry.pack(pady=20)
        self.reg_password_entry = customtkinter.CTkEntry(self.reg_window, placeholder_text ='Enter a Password')
        self.reg_password_entry.pack(pady=10)
        self.reg_button = customtkinter.CTkButton(self.reg_window, text = 'Register New User', command = self.commit_user)
        self.reg_button.pack(pady=20)
        self.login_button = customtkinter.CTkButton(self.reg_window, text='Login', command=self.login)
        self.login_button.pack(pady=5)
        self.reg_window.mainloop()

    #Commits the newly registered user to the database
    def commit_user(self):
        self.cursor.execute('SELECT username AND password, COUNT(*) FROM users WHERE username=%s AND password=%s GROUP BY username',(self.reg_username_entry.get(), self.reg_password_entry.get()))
        self.cursor.fetchall()
        self.row_count = self.cursor.rowcount
        if self.row_count == 1:
            self.my_label = customtkinter.CTkLabel(self.reg_window, text = 'User already exists', font=('Arial', 10)).pack(pady=10)
        else:
            self.cursor.execute('INSERT INTO users (username, password) VALUES(%s, %s)', (self.reg_username_entry.get(), self.reg_password_entry.get()))
            self.db.commit()
            self.login()
            self.reg_window.destroy()

    #provides the login screen where the user is asked for an existing username and password
    def login(self):
        self.login_window = customtkinter.CTk()
        self.login_window.geometry('400x400')
        self.login_username_entry = customtkinter.CTkEntry(self.login_window, placeholder_text ='Enter Your Username')
        self.login_username_entry.pack(pady=30)
        self.login_username = self.login_username_entry.get() 
        self.login_password_entry = customtkinter.CTkEntry(self.login_window, placeholder_text ='Enter Your Password')
        self.login_password_entry.pack(pady=30)
        self.login_password = self.login_password_entry.get()
        self.log_user_in_button = customtkinter.CTkButton(self.login_window, text = 'Login', command = self.log_user_in).pack(pady=30)
        self.reg_button = customtkinter.CTkButton(self.login_window, text = 'Register New User', command = self.reg_user)
        self.reg_button.pack(pady=20)
        self.login_window.mainloop()

    #Logs the user in
    def log_user_in(self):
        self.cursor.execute('SELECT username AND password, COUNT(*) FROM users WHERE username=%s AND password=%s GROUP BY username',(self.login_username_entry.get(), self.login_password_entry.get()))
        self.cursor.fetchall()
        self.row_count = self.cursor.rowcount
        if self.row_count == 1:
            self.cursor.execute('SELECT userID FROM users WHERE username=%s AND password=%s',(self.login_username_entry.get(), self.login_password_entry.get()))
            self.data = self.cursor.fetchone()
            for entry in self.data:
                self.user_id = self.data[0]
            habit_tracker.main_menu()
        else:
            self.my_label = customtkinter.CTkLabel(self.login_window, text = "User Not Found. Please Try Again.", font=('Helvetica', 10)).pack(pady=10)

class HabitTracker:
    def __init__(self, main_window, sorting_options, sort) -> None:
        self.main_window = main_window 
        self.db = mysql.connector.connect(host = 'yourneighbourhoodscientist.co.za', user = 'hoodscientist_hoodscientist', password= 'Kscanes3394#', database="hoodscientist_HabitTracker")
        self.cursor = self.db.cursor()
        self.sorting_options = sorting_options
        self.sort = sort 

    def main_menu(self):
        self.date = datetime.today()
        self.main_window = customtkinter.CTk()
        self.main_window.geometry('1080x720')
        self.sorting_options = ['Daily', 'Weekly', 'Monthly', 'Highest Streak',]
        self.mylabel = customtkinter.CTkLabel(self.main_window, text='Welcome {}'.format(login_reg.login_username_entry.get()), font=('Arial', 40)).pack(pady=5)
        self.sort = customtkinter.CTkComboBox(self.main_window, values= self.sorting_options, command= sort_by.sort_by)
        self.sort.set('Sort By')
        self.sort.pack(pady=10)
        self.create_new_habit_button = customtkinter.CTkButton(self.main_window, text='Create New Habit', command=create_habit.create_habit, fg_color='green').pack(pady=20)
        self.cursor.execute('SELECT habit_name FROM habit WHERE user_id=%s GROUP BY habit_name', (login_reg.data))
        self.habits = self.cursor.fetchall()
        self.j = 0
        for j in self.habits:
            self.habit_button = customtkinter.CTkButton(self.main_window, text=self.habits[self.j], command=lambda k = self.habits[self.j]: edit_habit.edit_habit(k))
            self.habit_button.pack(pady=10)
            self.j = self.j + 1
        self.main_window.mainloop()  

class EditHabit:

    def __init__(self, edit_window, habit_name, last_logged) -> None:
        self.db = mysql.connector.connect(host = 'yourneighbourhoodscientist.co.za', user = 'hoodscientist_hoodscientist', password= 'Kscanes3394#', database="hoodscientist_HabitTracker")
        self.cursor = self.db.cursor()
        self.edit_window = edit_window
        self.habit_name = habit_name
        self.last_logged = last_logged
    
    #Allows users to mark the habit as completed
    def edit_habit(self, var):
        self.edit_window = customtkinter.CTk()
        self.edit_window.geometry("500x500")
        self.habit_name = customtkinter.StringVar()
        self.habit_name.set(var)
        self.habit = str(var[0])
        self.cursor.execute('SELECT last_logged FROM habit WHERE user_id = %s AND habit_name = %s', (login_reg.user_id, self.habit))
        self.last_logged = self.cursor.fetchone()[0]
        self.commit_edit_button = customtkinter.CTkButton(self.edit_window, text="Log Habit", command= self.commit_edit).pack(pady=30)
        self.cursor.execute('SELECT frequency FROM habit WHERE user_id = %s AND habit_name = %s', (login_reg.user_id, self.habit))
        self.frequency = self.cursor.fetchone()[0]
        self.frequency_label = customtkinter.CTkLabel(self.edit_window, text='This is a {} habit'.format(self.frequency)).pack(pady=25)
        self.edit_label = customtkinter.CTkLabel(self.edit_window, text= "habit last logged on {}".format(self.last_logged)).pack(pady=30)
        self.edit_window.mainloop()

    #commits the hbait to the database
    def commit_edit(self):
        self.edit_window.destroy()
        self.cursor.execute('UPDATE habit SET last_logged = %s WHERE user_id = %s AND habit_name = %s', (habit_tracker.date, login_reg.user_id, self.habit ))
        self.cursor.execute('SELECT streak FROM habit WHERE user_id = %s AND habit_name = %s', (login_reg.user_id, self.habit))
        self.streak = self.cursor.fetchone()[0]
        self.logged = datetime.strptime(self.last_logged, '%Y-%m-%d %H:%M:%S.%f')
        self.consecutive_days = self.date - self.logged
        #checks to see if habit is daily
        if self.frequency == 'Daily' :
            if self.consecutive_days.days <= 7:
                self.cursor.execute("SELECT streak FROM habit WHERE habit_name = %s AND user_id = %s", (self.habit, login_reg.user_id))
                self.current_streak = self.cursor.fetchone()
                self.streak = self.current_streak[0]
                self.new_streak = self.streak
                self.new_streak = self.new_streak + 1
                self.cursor.execute('UPDATE habit SET streak = %s WHERE habit_name = %s AND user_id = %s', (self.new_streak, self.habit, login_reg.user_id))
                self.db.commit()
            else:
                self.new_streak=1
                self.cursor.execute('UPDATE habit SET streak = %s WHERE habit_name = %s AND user_id = %s', (self.new_streak, self.habit, login_reg.user_id))
                self.db.commit()
        #checks to see if habit is weekly
        if self.frequency == 'Weekly':
            if self.consecutive_days.days//7 <= 1:
                self.cursor.execute("SELECT streak FROM habit WHERE habit_name = %s AND user_id = %s", (self.habit, login_reg.user_id))
                self.current_streak = self.cursor.fetchone()
                self.streak = self.current_streak[0]
                self.new_streak = self.streak
                self.new_streak = self.new_streak + 1
                self.cursor.execute('UPDATE habit SET streak = %s WHERE habit_name = %s AND user_id = %s', (self.new_streak, self.habit, login_reg.user_id))
                self.db.commit()
            else:
                self.new_streak=1
                self.cursor.execute('UPDATE habit SET streak = %s WHERE habit_name = %s AND user_id = %s', (self.new_streak, self.habit, login_reg.user_id))
                self.db.commit()
        #Checks to see if habit is monthly
        if self.frequency == 'Monthly':
            if self.consecutive_days.days//30 <= 1:
                self.cursor.execute("SELECT streak FROM habit WHERE habit_name = %s AND user_id = %s", (self.habit, login_reg.user_id))
                self.current_streak = self.cursor.fetchall()
                self.streak = self.current_streak[0]
                self.new_streak = self.streak[0]
                self.new_streak = self.new_streak + 1
                self.cursor.execute('UPDATE habit SET streak = %s WHERE habit_name = %s AND user_id = %s', (self.new_streak, self.habit, login_reg.user_id))
                self.db.commit()
            else:
                self.new_streak=1
                self.cursor.execute('UPDATE habit SET streak = %s WHERE habit_name = %s AND user_id = %s', (self.new_streak, self.habit, login_reg.user_id))
                self.db.commit()

class CreateHabit:
    def __init__(self, create_habit_window, new_habit_entry):
        self.db = mysql.connector.connect(host = 'yourneighbourhoodscientist.co.za', user = 'hoodscientist_hoodscientist', password= 'Kscanes3394#', database="hoodscientist_HabitTracker")
        self.cursor = self.db.cursor()
        self.create_habit_window = create_habit_window
        self.new_habit_entry = new_habit_entry

     #Provides a screen for user to log a new habit and choose the frequency they want to do it
    def create_habit(self):
        self.create_habit_window = customtkinter.CTk()
        self.create_habit_window.geometry('500x500')
        self.new_habit_entry = customtkinter.CTkEntry(self.create_habit_window, placeholder_text='Enter Habit Name')
        self.new_habit_entry.pack(pady=30)
        self.options = ['Daily', 'Weekly', 'Monthly']
        self.new_habit_Combo = customtkinter.CTkComboBox(self.create_habit_window, values=self.options, )
        self.new_habit_Combo.pack(pady=20)
        self.new_habit_button = customtkinter.CTkButton(self.create_habit_window, text='Create New Habit', command= self.commit_habit)
        self.new_habit_button.pack(pady=30)
        self.create_habit_window.mainloop()

    #commits the habit to the database and creates a button to access the new habit
    def commit_habit(self):
        self.frequency = self.new_habit_Combo.get()
        self.habit_name = [self.new_habit_entry.get()]
        self.cursor.execute('INSERT INTO habit (habit_name, frequency, user_id, last_logged, streak) VALUES (%s, %s, %s, %s, 1)', (self.habit_name[0], self.frequency, login_reg.user_id, self.date))
        self.db.commit()
        self.create_habit_window.destroy()
        self.n = 1
        for j in range(self.n):
            self.habit_button= customtkinter.CTkButton(self.main_window, text=self.habit_name, command = lambda: self.edit_habit(self.habit_name))
            self.habit_button.pack(pady=20)
        self.main_window.update()

class SortBy:

    def __init__(self, selection, selection_window) -> None:
        self.db = mysql.connector.connect(host = 'yourneighbourhoodscientist.co.za', user = 'hoodscientist_hoodscientist', password= 'Kscanes3394#', database="hoodscientist_HabitTracker")
        self.cursor = self.db.cursor()
        self.selection = selection
        self.selection_window = selection_window
    

     #allows the user to sort the habits by frequency or highest streak
    def sort_by(self, sort_selection):
        self.selection = habit_tracker.sort.get()
        if self.selection == 'Daily':
            self.selection_window = customtkinter.CTk()
            self.selection_window.geometry('1080x720')
            self.sort_label = customtkinter.CTkLabel(self.selection_window, text = '{} Habits:'.format(self.selection)).pack(pady=25)
            self.cursor.execute('SELECT habit_name FROM habit WHERE user_id=%s AND frequency = %s', (login_reg.user_id, self.selection))
            self.sort_selection = self.cursor.fetchall()
            self.j = 0
            for j in self.sort_selection:
                self.habit_button = customtkinter.CTkButton(self.selection_window, text=self.sort_selection[self.j], command=lambda k = self.sort_selection[self.j]: self.edit_habit(k))
                self.habit_button.pack(pady=10)
                self.j = self.j + 1
            self.selection_window.mainloop()
            
        if self.selection == 'Weekly':
            self.selection_window = customtkinter.CTk()
            self.selection_window.geometry('1080x720')
            self.sort_label = customtkinter.CTkLabel(self.selection_window, text = '{} Habits:'.format(self.selection)).pack(pady=25)
            self.cursor.execute('SELECT habit_name FROM habit WHERE user_id=%s AND frequency = %s', (login_reg.user_id, self.selection))
            self.sort_selection = self.cursor.fetchall()
            self.j = 0
            for j in self.sort_selection:
                self.habit_button = customtkinter.CTkButton(self.selection_window, text=self.sort_selection[self.j], command=lambda k = self.sort_selection[self.j]: self.edit_habit(k))
                self.habit_button.pack(pady=10)
                self.j = self.j + 1
            self.selection_window.mainloop()

        if self.selection == 'Monthly':
            self.selection_window = customtkinter.CTk()
            self.selection_window.geometry('1080x720')
            self.sort_label = customtkinter.CTkLabel(self.selection_window, text = '{} Habits:'.format(self.selection)).pack(pady=25)
            self.cursor.execute('SELECT habit_name FROM habit WHERE user_id=%s AND frequency = %s', (login_reg.user_id, self.selection))
            self.sort_selection = self.cursor.fetchall()
            self.j = 0
            for j in self.sort_selection:
                self.habit_button = customtkinter.CTkButton(self.selection_window, text=self.sort_selection[self.j], command=lambda k = self.sort_selection[self.j]: self.edit_habit(k))
                self.habit_button.pack(pady=10)
                self.j = self.j + 1
            self.selection_window.mainloop()

        if self.selection== 'Highest Streak':
            self.selection_window = customtkinter.CTk()
            self.selection_window.geometry('1080x720')
            self.id = [login_reg.user_id]
            self.sort_label = customtkinter.CTkLabel(self.selection_window, text = '{} Habits:'.format(self.selection)).pack(pady=25)
            self.cursor.execute('SELECT habit_name, MAX(streak) FROM habit WHERE user_id=%s GROUP BY frequency', (self.id))
            self.sort_selection = self.cursor.fetchall()
            self.j = 0
            for j in self.sort_selection:
                self.habit_button = customtkinter.CTkButton(self.selection_window, text=self.sort_selection[self.j], command=lambda k = self.sort_selection[self.j]: self.edit_habit(k))
                self.habit_button.pack(pady=10)
                self.j = self.j + 1
            self.selection_window.mainloop()
 


sort_by = SortBy(selection= ' ', selection_window=' ')
create_habit = CreateHabit(create_habit_window= ' ', new_habit_entry= ' ')
edit_habit = EditHabit(edit_window= ' ', habit_name= ' ', last_logged=' ')
habit_tracker = HabitTracker(main_window= ' ', sorting_options= ' ', sort = " ")
login_reg = LoginOrReg(db = " ", cursor=" ", login_username= ' ', data = ' ')
login_reg.login_or_reg(root=" ")
