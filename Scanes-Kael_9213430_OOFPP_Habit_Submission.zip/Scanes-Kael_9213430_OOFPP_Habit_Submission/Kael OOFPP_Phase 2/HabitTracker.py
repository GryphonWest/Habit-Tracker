from tkinter import *
import mysql.connector
import customtkinter
import math
from datetime import datetime

class HabitTracker:
    def __init__(self, main_window, sorting_options, sort, date) -> None:
        self.main_window = main_window 
        self.db = mysql.connector.connect(host = 'yourneighbourhoodscientist.co.za', user = 'hoodscientist_hoodscientist', password= 'Kscanes3394#', database="hoodscientist_HabitTracker")
        self.cursor = self.db.cursor()
        self.sorting_options = sorting_options
        self.sort = sort 
        self.date = date
        
    def main_menu(self, lor,tracker):
        import LoginOrReg as LR
        self.login = lor
        self.date = datetime.today()
        self.main_window = customtkinter.CTk()
        self.main_window.geometry('1080x720')
        self.sorting_options = ['Daily', 'Weekly', 'Monthly', 'Highest Streak',]
        self.mylabel = customtkinter.CTkLabel(self.main_window, text='Welcome {}'.format(self.login.login_username_entry.get()), font=('Arial', 40)).pack(pady=5)
        self.sort = customtkinter.CTkComboBox(self.main_window, values= self.sorting_options, command=lambda selection: SortBy.sort_by(self, sort_selection=selection))
        self.sort.set('Sort By')
        self.sort.pack(pady=10)
        def create_lambda():
        
            return(lambda: create_habit.create_habit(lor))
        self.create_new_habit_button = customtkinter.CTkButton(self.main_window, text='Create New Habit', command=create_lambda(), fg_color='green').pack(pady=20)
        self.cursor.execute('SELECT habit_name FROM habit WHERE user_id=%s GROUP BY habit_name', (self.login.data["userID"],))
        self.habits = self.cursor.fetchall()
        self.j = 0
        for j in self.habits:
            self.habit_button = customtkinter.CTkButton(self.main_window, text=self.habits[self.j], command=lambda k = self.habits[self.j]: edit_habit.edit_habit(k, lor, self))
            self.habit_button.pack(pady=10)
            self.j = self.j + 1
        self.main_window.mainloop()  

class EditHabit:

    def __init__(self, edit_window, habit_name, last_logged) -> None:
        self.db = mysql.connector.connect(host = 'yourneighbourhoodscientist.co.za', user = 'hoodscientist_hoodscientist', password= 'Kscanes3394#', database="hoodscientist_HabitTracker")
        self.cursor = self.db.cursor()
        self.edit_window = edit_window
        self.habit_name = habit_name
        self.last_logged = last_logged
    
    #Allows users to mark the habit as completed
    def edit_habit(self, var, lor, tracker):
        import LoginOrReg as LR
        self.login = lor
        self.edit_window = customtkinter.CTk()
        self.edit_window.geometry("500x500")
        self.habit_name = customtkinter.StringVar()
        self.habit_name.set(var)
        self.habit = str(var[0])
        self.cursor.execute('SELECT last_logged FROM habit WHERE user_id = %s AND habit_name = %s', (self.login.user_id, self.habit))
        self.last_logged = self.cursor.fetchone()[0]
        print(type(self.last_logged))
        self.commit_edit_button = customtkinter.CTkButton(self.edit_window, text="Log Habit", command=lambda habittracker=tracker: self.commit_edit(habittracker)).pack(pady=30)
        self.cursor.execute('SELECT frequency FROM habit WHERE user_id = %s AND habit_name = %s', (self.login.user_id, self.habit))
        self.frequency = self.cursor.fetchone()[0]
        self.frequency_label = customtkinter.CTkLabel(self.edit_window, text='This is a {} habit'.format(self.frequency)).pack(pady=25)
        self.edit_label = customtkinter.CTkLabel(self.edit_window, text= "habit last logged on {}".format(self.last_logged)).pack(pady=30)
        self.edit_window.mainloop()

    #commits the habit to the database
    def commit_edit(self, habittracker):
        self.edit_window.destroy()
        print('This is a ', type(habittracker.date))
        self.cursor.execute('UPDATE habit SET last_logged = %s WHERE user_id = %s AND habit_name = %s', (datetime.strptime(str(habittracker.date), '%Y-%m-%d %H:%M:%S.%f'), self.login.user_id, self.habit ))
        self.cursor.execute('SELECT streak FROM habit WHERE user_id = %s AND habit_name = %s', (self.login.user_id, self.habit))
        self.streak = self.cursor.fetchone()[0]
        print(self.last_logged)
        # try:
        #     self.logged = datetime.strptime(self.last_logged, '%Y-%m-%d %H:%M:%S.%f')   
        #     self.consecutive_days = self.date - self.logged
        # except:
        #     self.consecutive_days=1
        self.logged = datetime.strptime(self.last_logged, '%Y-%m-%d %H:%M:%S.%f')   
        self.consecutive_days = datetime.now() - self.logged
        print(self.consecutive_days)
        #checks to see if habit is daily
        frequency_dict= {
            'Daily' : 1,
            'Weekly' : 7,
            'Monthly' : 30
        }
        if self.consecutive_days.days//frequency_dict[self.frequency]<=1:
            self.cursor.execute("SELECT streak FROM habit WHERE habit_name = %s AND user_id = %s", (self.habit, self.login.user_id))
            self.current_streak = self.cursor.fetchone()
            self.streak = self.current_streak[0]
            self.new_streak = self.streak
            self.new_streak = self.new_streak + 1
            self.cursor.execute('UPDATE habit SET streak = %s WHERE habit_name = %s AND user_id = %s', (self.new_streak, self.habit, self.login.user_id))
            self.db.commit()
        else:
            self.new_streak=1
            self.cursor.execute('UPDATE habit SET streak = %s WHERE habit_name = %s AND user_id = %s', (self.new_streak, self.habit, self.login.user_id))
            self.db.commit()
        
class CreateHabit:
    def __init__(self, create_habit_window, new_habit_entry):
        self.db = mysql.connector.connect(host='yourneighbourhoodscientist.co.za', user='hoodscientist_hoodscientist', password='Kscanes3394#', database="hoodscientist_HabitTracker")
        self.cursor = self.db.cursor()
        self.create_habit_window = create_habit_window
        self.new_habit_entry = new_habit_entry

     #Provides a screen for user to log a new habit and choose the frequency they want to do it
    def create_habit(self, lor):
        import LoginOrReg as LR
        self.login = lor
        self.create_habit_window = customtkinter.CTk()
        self.create_habit_window.geometry('500x500')
        self.new_habit_entry = customtkinter.CTkEntry(self.create_habit_window, placeholder_text='Enter Habit Name')
        self.new_habit_entry.pack(pady=30)
        self.options = ['Daily', 'Weekly', 'Monthly']
        self.new_habit_Combo = customtkinter.CTkComboBox(self.create_habit_window, values=self.options, )
        self.new_habit_Combo.pack(pady=20)
        self.new_habit_button = customtkinter.CTkButton(self.create_habit_window, text='Create New Habit', command= self.commit_habit)
        self.new_habit_button.pack(pady=30)
        self.create_habit_window.mainloop()

    #commits the habit to the database and creates a button to access the new habit
    def commit_habit(self):
        self.frequency = self.new_habit_Combo.get()
        self.habit_name = [self.new_habit_entry.get()]
        self.cursor.execute('INSERT INTO habit (habit_name, frequency, user_id, last_logged, streak) VALUES (%s, %s, %s, %s, 0)', (self.habit_name[0], self.frequency, self.login.user_id, datetime.now()))
        self.db.commit()
        self.create_habit_window.destroy()
        self.n = 1
        for j in range(self.n):
            self.habit_button= customtkinter.CTkButton(self.main_window, text=self.habit_name, command = lambda: edit_habit.edit_habit(self.habit_name))
            self.habit_button.pack(pady=20)

class SortBy:

    def __init__(self, selection, selection_window) -> None:
        self.db = mysql.connector.connect(host = 'yourneighbourhoodscientist.co.za', user = 'hoodscientist_hoodscientist', password= 'Kscanes3394#', database="hoodscientist_HabitTracker")
        self.cursor = self.db.cursor()
        self.selection = selection
        self.selection_window = selection_window
    

     #allows the user to sort the habits by frequency or highest streak
    def sort_by(self, sort_selection):
        self.selection = sort_selection
        match (self.selection):
            case 'Daily':  
                self.selection_window = customtkinter.CTk()
                self.selection_window.geometry('1080x720')
                self.sort_label = customtkinter.CTkLabel(self.selection_window, text = '{} Habits:'.format(self.selection)).pack(pady=25)
                self.cursor.execute('SELECT habit_name FROM habit WHERE user_id=%s AND frequency = %s', (self.login.user_id, self.selection))
                self.sort_selection = self.cursor.fetchall()
                self.j = 0
                for j in self.sort_selection:
                    self.habit_button = customtkinter.CTkButton(self.selection_window, text=self.sort_selection[self.j], command=lambda k = self.sort_selection[self.j]: self.edit_habit(k))
                    self.habit_button.pack(pady=10)
                    self.j = self.j + 1
                self.selection_window.mainloop()
            case 'Weekly':
                self.selection_window = customtkinter.CTk()
                self.selection_window.geometry('1080x720')
                self.sort_label = customtkinter.CTkLabel(self.selection_window, text = '{} Habits:'.format(self.selection)).pack(pady=25)
                self.cursor.execute('SELECT habit_name FROM habit WHERE user_id=%s AND frequency = %s', (self.login.user_id, self.selection))
                self.sort_selection = self.cursor.fetchall()
                self.j = 0
                for j in self.sort_selection:
                    self.habit_button = customtkinter.CTkButton(self.selection_window, text=self.sort_selection[self.j], command=lambda k = self.sort_selection[self.j]: self.edit_habit(k))
                    self.habit_button.pack(pady=10)
                    self.j = self.j + 1
                self.selection_window.mainloop()
            case 'Monthly':
                self.selection_window = customtkinter.CTk()
                self.selection_window.geometry('1080x720')
                self.sort_label = customtkinter.CTkLabel(self.selection_window, text = '{} Habits:'.format(self.selection)).pack(pady=25)
                self.cursor.execute('SELECT habit_name FROM habit WHERE user_id=%s AND frequency = %s', (self.login.user_id, self.selection))
                self.sort_selection = self.cursor.fetchall()
                self.j = 0
                for j in self.sort_selection:
                    self.habit_button = customtkinter.CTkButton(self.selection_window, text=self.sort_selection[self.j], command=lambda k = self.sort_selection[self.j]: self.edit_habit(k))
                    self.habit_button.pack(pady=10)
                    self.j = self.j + 1
                self.selection_window.mainloop()
            case 'Highest Streak':
                self.selection_window = customtkinter.CTk()
                self.selection_window.geometry('1080x720')
                self.id = [self.login.user_id]
                self.sort_label = customtkinter.CTkLabel(self.selection_window, text = '{} Habits:'.format(self.selection)).pack(pady=25)
                self.cursor.execute('SELECT habit_name, MAX(streak) FROM habit WHERE user_id=%s GROUP BY frequency', (self.id))
                self.sort_selection = self.cursor.fetchall()
                self.j = 0
                for j in self.sort_selection:
                    self.habit_button = customtkinter.CTkButton(self.selection_window, text=self.sort_selection[self.j], command=lambda k = self.sort_selection[self.j]: self.edit_habit(k))
                    self.habit_button.pack(pady=10)
                    self.j = self.j + 1
                self.selection_window.mainloop()   


# if __name__ == '__main__':
sort_by = SortBy(selection= ' ', selection_window=' ')
create_habit = CreateHabit(create_habit_window= ' ', new_habit_entry= ' ')
edit_habit = EditHabit(edit_window= ' ', habit_name= ' ', last_logged=' ')
habit_tracker = HabitTracker(main_window= ' ', sorting_options= ' ', sort = " ", date=' ')