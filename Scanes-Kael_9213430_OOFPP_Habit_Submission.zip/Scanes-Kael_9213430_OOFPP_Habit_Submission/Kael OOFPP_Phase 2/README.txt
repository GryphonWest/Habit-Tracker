Good day

Here is you will see important information regarding the program.
To get to the test Data you must use:
Username: Test
Password: Admin

In this user you will see that I have a range of tasks, some daily, some weekly and some monthly.
Feel free to create and track your own habits

After you have created a new habit you must exit the program and re-enter for the new habit to show as a button.